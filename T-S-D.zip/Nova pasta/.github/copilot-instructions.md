# T.S.D — Documento de Requisitos do Produto (PRD)

**Status:** Especificação para protótipo  
**Produto:** T.S.D  
**Plataforma:** Aplicativo web client-side  
**Idioma da interface:** Português do Brasil  
**Público principal:** Representantes comerciais e seus supervisores

## 1. Visão geral do produto

O T.S.D ajuda representantes comerciais a registrar, organizar e prestar contas dos gastos de viagens e encontros com clientes. O produto relaciona despesas, adiantamentos e comprovantes a uma viagem, calcula o saldo disponível ou o valor a ressarcir e permite que um supervisor acompanhe os custos.

O critério central para classificar uma despesa é sua finalidade. Gastos necessários para a atividade profissional, como alimentação durante o trabalho e locomoção entre compromissos, podem ser atribuídos à empresa. Gastos de preferência ou benefício pessoal devem ser atribuídos ao representante. A classificação deve ser explícita, acompanhada de justificativa e editável no protótipo; o aplicativo não deve decidir automaticamente a responsabilidade com base em uma regra de IA.

## 2. Público-alvo e perfis

### Representante comercial

- Registra despesas e entradas vinculadas a uma viagem.
- Informa a justificativa e quem é responsável pelo pagamento.
- Anexa fotos ou arquivos de comprovantes.
- Acompanha o saldo e prepara a prestação de contas.

### Supervisor ou administrador

- Seleciona um representante e uma viagem.
- Consulta despesas, entradas, saldo, comprovantes e evolução de gastos.

No protótipo, os perfis são demonstrações selecionáveis pela interface. Não há autenticação, autorização real nem sincronização entre usuários.

## 3. Objetivos e escopo

### Objetivos do protótipo

1. Demonstrar os principais fluxos de registro e acompanhamento de uma viagem.
2. Classificar despesas como pagas pela empresa, pelo representante ou compartilhadas.
3. Atualizar o saldo da viagem após o registro de despesas e entradas.
4. Destacar despesas sem comprovantes.
5. Permitir ao supervisor consultar os dados de demonstração de uma viagem.
6. Exportar os lançamentos e o resumo financeiro para um arquivo CSV.
7. Demonstrar uma previsão ilustrativa de custos com base no destino e no itinerário.

### Incluído

- Interface responsiva para desktop e dispositivos móveis.
- As seis áreas de navegação descritas neste documento.
- Dados realistas de demonstração para representantes, viagens, despesas, entradas e comprovantes.
- Persistência local de alterações no navegador por meio de `localStorage`.
- Inclusão e edição de despesas; inclusão de entradas.
- Anexo local de comprovantes de demonstração.
- Filtro de despesas por categoria.
- Exportação CSV gerada no navegador.
- Seletor de perfil Representante / Superior-Admin.

### Fora do escopo

- Backend, API ou banco de dados remoto.
- Login, autenticação ou permissões de produção.
- Upload de arquivos para servidor ou armazenamento seguro de documentos.
- Integração bancária, pagamentos, transferências ou conciliação financeira.
- Integração real com mapas, hotéis, restaurantes ou serviços de IA.
- Comunicação em tempo real, WebSockets ou colaboração simultânea.
- Envio de relatórios por e-mail.
- Aprovação formal de despesas por gestores.

## 4. Casos de uso principais

### UC-01 — Consultar o painel da viagem

1. O usuário seleciona uma viagem ativa.
2. O painel mostra empresa, representante, objetivo, destino e período.
3. O usuário consulta despesas, entradas, saldo, transações e situação dos comprovantes.
4. O usuário pode abrir a lista de despesas a partir dos indicadores ou categorias.

### UC-02 — Registrar ou editar uma despesa

1. O representante abre a área Despesas e seleciona adicionar ou editar.
2. Informa descrição, categoria, valor, data, local, finalidade e responsabilidade pelo pagamento.
3. Se a despesa for compartilhada, informa as parcelas da empresa e do representante.
4. Opcionalmente, anexa uma imagem ou arquivo de comprovante.
5. Salva o lançamento; os totais e o saldo são recalculados.
6. Se não houver comprovante, a despesa fica marcada como pendente.

### UC-03 — Registrar uma entrada

1. O representante abre Entradas e informa valor, data e descrição.
2. O sistema adiciona o valor às entradas da viagem selecionada.
3. O saldo é atualizado imediatamente nas telas que o apresentam.

### UC-04 — Consultar uma estimativa de viagem

1. O usuário abre Itinerário e previsão.
2. Consulta destino, período e estimativas simuladas de hospedagem, alimentação e locomoção.
3. A interface deixa claro que estimativas e recomendações são dados fictícios de demonstração.

### UC-05 — Acompanhar uma viagem como supervisor

1. O usuário alterna para o perfil Superior/Admin.
2. Seleciona um representante e uma viagem disponível.
3. Consulta totais, saldo, comprovantes pendentes e gastos ao longo do tempo.
4. Pode abrir a lista de despesas da viagem.

### UC-06 — Revisar e exportar o relatório

1. O representante abre Relatório.
2. Confere entradas, despesas, saldo e situação dos comprovantes.
3. Exporta um arquivo CSV compatível com planilhas.

## 5. Navegação e requisitos por tela

A aplicação deve ter uma navegação lateral que permita alternar entre as telas abaixo. Em telas menores, a navegação pode se reduzir visualmente a ícones, mas cada controle deve continuar acessível e identificável.

### 5.1 Painel inicial (Dashboard)

Exibir para a viagem ativa:

- Empresa, representante, objetivo, destino e período.
- Total de despesas e total de entradas.
- Saldo disponível ou valor a ressarcir.
- Quantidade de transações.
- Quantidade de comprovantes enviados e pendentes.
- Distribuição de despesas por categoria ou local.
- Atividade recente.
- Aviso claro quando houver comprovantes pendentes.

Ao selecionar um indicador de despesas, aviso de comprovantes ou categoria, abrir Despesas, aplicando filtro quando pertinente.

### 5.2 Despesas (Expenses)

Exibir uma lista ou tabela com:

- Descrição, categoria, valor, data e local.
- Finalidade ou justificativa.
- Responsabilidade: empresa, representante ou compartilhada.
- Situação do comprovante: enviado ou pendente.

Permitir adicionar e editar despesas, filtrar por categoria e anexar um arquivo local. Mostrar claramente “Comprovante pendente” quando não houver arquivo.

### 5.3 Entradas (Advances)

Permitir registrar e consultar adiantamentos recebidos da empresa, com valor, data e descrição/observação. Mostrar o total de entradas da viagem e atualizar o saldo após cada novo lançamento.

### 5.4 Itinerário e previsão (Itinerary & Forecast)

Mostrar destino e período da viagem e uma previsão ilustrativa separada por hospedagem, alimentação e transporte. Exibir um aviso visível de que os valores e sugestões são simulados e não vêm de mapas, IA ou serviços externos.

### 5.5 Administrativo (Admin)

Permitir selecionar um representante e uma de suas viagens. Apresentar um resumo com despesas, entradas, saldo, comprovantes pendentes e uma visualização temporal dos gastos. As ações dessa tela devem refletir os dados locais da viagem selecionada.

### 5.6 Relatório (Report)

Apresentar um resumo da viagem, entradas, despesas, saldo e conferência dos comprovantes. O botão “Exportar CSV” deve gerar e baixar o arquivo diretamente no navegador.

## 6. Regras de negócio e cálculos

1. **Saldo da viagem = total de entradas da viagem − total de despesas da viagem.**
2. Saldo positivo significa dinheiro disponível. Exibi-lo em azul e com o rótulo “Disponível”.
3. Saldo negativo significa valor a ressarcir ao representante. Exibir o valor absoluto em vermelho, com o rótulo “A ressarcir”.
4. Saldo igual a zero deve ser identificado explicitamente como saldo zerado, sem mostrar um valor negativo.
5. Os cálculos são feitos por viagem; despesas e entradas de outra viagem não devem alterar o saldo selecionado.
6. Cada despesa possui uma única responsabilidade: Empresa, Representante ou Compartilhada.
7. Para uma despesa da empresa, a parcela da empresa corresponde ao total e a parcela do representante é zero. Para uma despesa do representante, aplica-se o inverso.
8. Para uma despesa compartilhada, a soma das parcelas da empresa e do representante deve ser exatamente igual ao total da despesa, com precisão de centavos. Caso contrário, impedir o salvamento e explicar o erro.
9. A classificação deve ser acompanhada por uma justificativa da finalidade do gasto; o protótipo não determina a classificação automaticamente.
10. Uma despesa pode ser salva sem comprovante, mas deve continuar marcada como pendente.
11. Valores devem ser apresentados em reais, com duas casas decimais, usando o padrão brasileiro (`R$ 1.234,56`).
12. O CSV deve incluir despesas, entradas, categorias, responsabilidades, parcelas compartilhadas, sinalização de comprovantes pendentes e resumo dos totais e saldo.

## 7. Dados de demonstração

Incluir dados fictícios suficientes para demonstrar:

- Pelo menos dois representantes e suas viagens.
- Destinos, empresas, objetivos e períodos.
- Despesas em categorias variadas, incluindo alimentação, hospedagem e transporte.
- Uma despesa atribuída ao representante ou compartilhada.
- Comprovantes enviados e despesas com comprovantes pendentes.
- Uma ou mais entradas por viagem.
- Cenários de saldo positivo e, se possível, um cenário de saldo negativo para demonstrar “A ressarcir”.

Campos mínimos de uma despesa:

`id`, `tripId`, `description`, `category`, `amount`, `date`, `location`, `purpose`, `responsibility`, `companyShare`, `representativeShare` e dados/nome do comprovante.

Campos mínimos de uma entrada:

`id`, `tripId`, `amount`, `date` e `description`.

Campos mínimos de uma viagem:

`id`, `representativeId`, `company`, `purpose`, `destination`, `startDate` e `endDate`.

Não utilizar dados pessoais, notas fiscais ou informações financeiras reais na demonstração.

## 8. Requisitos de interface, acessibilidade e experiência

- Interface simples, intuitiva e responsiva.
- Navegação entre as seis telas principais, com indicação visual da tela ativa.
- Azul para saldo disponível, vermelho para valores a ressarcir e alertas importantes e verde para confirmações ou entradas registradas.
- Nunca comunicar estados apenas por cor: incluir rótulos e texto compreensível.
- Formulários com rótulos, validação e mensagens de erro claras.
- Animações discretas, sem prejudicar desempenho ou navegação.
- Respeitar a preferência de movimento reduzido do sistema.
- Usar controles identificáveis por teclado, estados de foco visíveis e contraste adequado.
- Em telas estreitas, adaptar tabelas e formulários para evitar perda de informação e rolagem horizontal desnecessária.

## 9. Requisitos técnicos e limitações

- Aplicação client-side criada com **React, TypeScript, HTML e CSS**, utilizando **Vite**.
- Persistência de dados de demonstração no `localStorage` do navegador.
- Exportação CSV criada localmente, sem enviar informações para um servidor.
- Anexos armazenados apenas localmente no navegador, sujeitos aos limites de armazenamento do dispositivo.
- Não exigir backend ou serviços externos para executar os fluxos do protótipo.
- Fornecer instruções para instalar dependências e executar localmente.

O `localStorage` não garante armazenamento seguro, permanente ou compartilhado. O protótipo não deve ser utilizado para guardar comprovantes reais ou dados sensíveis. A alternância de perfil é apenas visual; não representa controle de acesso. O painel administrativo não recebe dados de outro usuário. Avisos de usuário simultaneamente conectado ou edição colaborativa em tempo real não fazem parte deste protótipo.

## 10. Critérios de aceitação

- [ ] A aplicação inicia localmente com Vite e permite navegar pelas seis telas.
- [ ] O layout se ajusta a desktop e dispositivos móveis; em telas menores, a navegação permanece utilizável.
- [ ] Dados de demonstração são apresentados na primeira execução.
- [ ] Alterações feitas pelo usuário são mantidas ao atualizar a página, no mesmo navegador.
- [ ] Selecionar uma viagem atualiza os dados e cálculos exibidos.
- [ ] Registrar ou editar uma despesa atualiza imediatamente os totais da viagem.
- [ ] Registrar uma entrada atualiza imediatamente o saldo nas telas correspondentes.
- [ ] Com entradas de R$ 15.000,00 e despesas de R$ 10.000,00, o saldo exibido é “Disponível: R$ 5.000,00”.
- [ ] Quando as despesas excedem as entradas, o valor absoluto do saldo é exibido como “A ressarcir”, em vermelho.
- [ ] Despesas sem comprovante aparecem como pendentes nos painéis e no relatório.
- [ ] É possível anexar um comprovante local a uma despesa; o estado passa a “Enviado”.
- [ ] Despesas compartilhadas não podem ser salvas quando as parcelas não totalizam o valor da despesa.
- [ ] Selecionar um indicador ou categoria de despesas abre a lista de despesas apropriada.
- [ ] Alternar para Superior/Admin abre a visão administrativa demonstrativa; alternar de volta retorna à visão do representante.
- [ ] A tela administrativa permite selecionar representante e viagem e mostra dados correspondentes aos dados locais.
- [ ] Estimativas e recomendações do itinerário são identificadas claramente como simuladas.
- [ ] O botão de exportação baixa um CSV que pode ser aberto em planilhas e contém lançamentos, responsabilidades, comprovantes e resumo financeiro.
- [ ] Textos de status acompanham as cores, incluindo “Disponível”, “A ressarcir” e “Pendente”.

## 11. Entregáveis e execução

O protótipo deve incluir:

- Código-fonte React e TypeScript, estilos responsivos e configuração Vite.
- Dados fictícios de demonstração.
- Arquivo CSV gerado pelo fluxo de relatório.
- Instruções para instalar dependências, iniciar o protótipo e validar a compilação.
- Acesso demonstrável aos fluxos de representante e supervisor, sem exigir conta real.

## 12. Próximas etapas possíveis (fora do protótipo)

Após validar o protótipo, uma versão de produção poderá exigir decisões específicas sobre autenticação e autorização, backend, banco de dados, armazenamento seguro de comprovantes, políticas corporativas de reembolso, integração bancária, serviços de mapas/IA, auditoria, colaboração em tempo real e retenção de dados. Essas capacidades não devem ser simuladas como integrações reais nesta entrega.
