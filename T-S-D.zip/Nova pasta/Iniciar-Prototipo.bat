@echo off
setlocal
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js nao foi encontrado.
  echo Instale a versao LTS em https://nodejs.org/ e execute este arquivo novamente.
  pause
  exit /b 1
)

if not exist "node_modules\vite\bin\vite.js" (
  echo Instalando as dependencias do prototipo...
  call npm install
  if errorlevel 1 (
    echo Nao foi possivel instalar as dependencias.
    pause
    exit /b 1
  )
)

echo Iniciando o prototipo T.S.D...
echo Acesse http://localhost:5173 no Google Chrome.
echo Mantenha esta janela aberta enquanto usa o prototipo.
call npm run dev -- --host 127.0.0.1 --strictPort --open
pause
