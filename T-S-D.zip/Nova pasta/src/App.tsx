import { type ChangeEvent, type FormEvent, type ReactNode, useEffect, useMemo, useState } from "react";

type View = "dashboard" | "expenses" | "advances" | "itinerary" | "admin" | "report";
type Responsibility = "company" | "representative" | "shared";
type Role = "representative" | "admin";

interface Representative {
  id: string;
  name: string;
  initials: string;
}

interface Trip {
  id: string;
  representativeId: string;
  company: string;
  purpose: string;
  destination: string;
  startDate: string;
  endDate: string;
}

interface Expense {
  id: string;
  tripId: string;
  description: string;
  category: string;
  amount: number;
  date: string;
  location: string;
  purpose: string;
  responsibility: Responsibility;
  companyShare: number;
  representativeShare: number;
  receiptName: string;
  receiptData: string;
}

interface Advance {
  id: string;
  tripId: string;
  amount: number;
  date: string;
  description: string;
}

interface AppData {
  representatives: Representative[];
  trips: Trip[];
  expenses: Expense[];
  advances: Advance[];
  activeTripId: string;
}

const STORAGE_KEY = "tsd-prototype-data-v1";
const CATEGORIES = ["Alimentação", "Hospedagem", "Transporte", "Reunião", "Outros"];
const VIEW_ITEMS: { id: View; label: string; icon: string }[] = [
  { id: "dashboard", label: "Painel inicial", icon: "⌂" },
  { id: "expenses", label: "Despesas", icon: "↗" },
  { id: "advances", label: "Entradas", icon: "＋" },
  { id: "itinerary", label: "Itinerário e previsão", icon: "⌖" },
  { id: "admin", label: "Administrativo", icon: "▣" },
  { id: "report", label: "Relatório", icon: "▤" },
];

const demoData: AppData = {
  representatives: [
    { id: "rep-1", name: "Mariana Costa", initials: "MC" },
    { id: "rep-2", name: "Rafael Martins", initials: "RM" },
  ],
  trips: [
    {
      id: "trip-1",
      representativeId: "rep-1",
      company: "NorteSul Equipamentos",
      purpose: "Visita a clientes e apresentação de catálogo",
      destination: "São Paulo, SP",
      startDate: "2026-10-20",
      endDate: "2026-10-24",
    },
    {
      id: "trip-2",
      representativeId: "rep-2",
      company: "NorteSul Equipamentos",
      purpose: "Negociação com distribuidores",
      destination: "Curitiba, PR",
      startDate: "2026-10-21",
      endDate: "2026-10-23",
    },
  ],
  expenses: [
    {
      id: "exp-1", tripId: "trip-1", description: "Almoço com cliente", category: "Alimentação",
      amount: 186.5, date: "2026-10-20", location: "Vila Olímpia, SP",
      purpose: "Reunião comercial com a equipe da Alfa", responsibility: "company",
      companyShare: 186.5, representativeShare: 0, receiptName: "nota-almoco.jpg", receiptData: "",
    },
    {
      id: "exp-2", tripId: "trip-1", description: "Aplicativo de transporte", category: "Transporte",
      amount: 74.9, date: "2026-10-20", location: "São Paulo, SP",
      purpose: "Deslocamento até o cliente", responsibility: "company",
      companyShare: 74.9, representativeShare: 0, receiptName: "recibo-transporte.pdf", receiptData: "",
    },
    {
      id: "exp-3", tripId: "trip-1", description: "Hotel Central", category: "Hospedagem",
      amount: 1240, date: "2026-10-20", location: "Pinheiros, SP",
      purpose: "Hospedagem durante a viagem de trabalho", responsibility: "company",
      companyShare: 1240, representativeShare: 0, receiptName: "nota-hotel.jpg", receiptData: "",
    },
    {
      id: "exp-4", tripId: "trip-1", description: "Jantar após reunião", category: "Alimentação",
      amount: 248, date: "2026-10-21", location: "Itaim Bibi, SP",
      purpose: "Refeição com cliente após apresentação", responsibility: "shared",
      companyShare: 180, representativeShare: 68, receiptName: "", receiptData: "",
    },
    {
      id: "exp-5", tripId: "trip-1", description: "Estacionamento", category: "Transporte",
      amount: 42, date: "2026-10-22", location: "Centro, SP",
      purpose: "Visita a cliente", responsibility: "company",
      companyShare: 42, representativeShare: 0, receiptName: "", receiptData: "",
    },
    {
      id: "exp-6", tripId: "trip-2", description: "Refeição de trabalho", category: "Alimentação",
      amount: 132, date: "2026-10-21", location: "Batel, Curitiba",
      purpose: "Almoço entre reuniões com distribuidores", responsibility: "company",
      companyShare: 132, representativeShare: 0, receiptName: "refeicao.jpg", receiptData: "",
    },
  ],
  advances: [
    { id: "adv-1", tripId: "trip-1", amount: 2500, date: "2026-10-19", description: "Adiantamento inicial" },
    { id: "adv-2", tripId: "trip-1", amount: 800, date: "2026-10-21", description: "Complemento para hospedagem" },
    { id: "adv-3", tripId: "trip-2", amount: 1200, date: "2026-10-20", description: "Adiantamento de viagem" },
  ],
  activeTripId: "trip-1",
};

const brl = (value: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(value);

const formatDate = (value: string) =>
  new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "short", year: "numeric" }).format(
    new Date(`${value}T12:00:00`),
  );

function readSavedData(): AppData {
  try {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (!saved) return demoData;
    return JSON.parse(saved) as AppData;
  } catch (error) {
    console.error("Não foi possível ler os dados salvos do T.S.D.", error);
    return demoData;
  }
}

function localDateValue() {
  const now = new Date();
  const localDate = new Date(now.getTime() - now.getTimezoneOffset() * 60_000);
  return localDate.toISOString().slice(0, 10);
}

function App() {
  const [data, setData] = useState<AppData>(readSavedData);
  const [view, setView] = useState<View>("dashboard");
  const [role, setRole] = useState<Role>("representative");
  const [filterCategory, setFilterCategory] = useState("");
  const [storageError, setStorageError] = useState(false);
  const [modal, setModal] = useState<"expense" | "advance" | null>(null);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [adminRepresentativeId, setAdminRepresentativeId] = useState(data.representatives[0]?.id ?? "");

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      setStorageError(false);
    } catch (error) {
      console.error("Não foi possível salvar os dados do T.S.D.", error);
      setStorageError(true);
    }
  }, [data]);

  const activeTrip = data.trips.find((trip) => trip.id === data.activeTripId) ?? data.trips[0];
  const currentRep = data.representatives.find((rep) => rep.id === activeTrip?.representativeId);
  const tripExpenses = data.expenses.filter((expense) => expense.tripId === activeTrip?.id);
  const tripAdvances = data.advances.filter((advance) => advance.tripId === activeTrip?.id);
  const totalExpenses = tripExpenses.reduce((sum, expense) => sum + expense.amount, 0);
  const totalAdvances = tripAdvances.reduce((sum, advance) => sum + advance.amount, 0);
  const balance = totalAdvances - totalExpenses;
  const pendingReceipts = tripExpenses.filter((expense) => !expense.receiptName).length;
  const submittedReceipts = tripExpenses.length - pendingReceipts;

  const goToExpenses = (category = "") => {
    setFilterCategory(category);
    setView("expenses");
  };

  const saveExpense = (expense: Expense) => {
    setData((current) => ({
      ...current,
      expenses: current.expenses.some((item) => item.id === expense.id)
        ? current.expenses.map((item) => item.id === expense.id ? expense : item)
        : [expense, ...current.expenses],
    }));
    setModal(null);
    setEditingExpense(null);
  };

  const saveAdvance = (advance: Advance) => {
    setData((current) => ({ ...current, advances: [advance, ...current.advances] }));
    setModal(null);
  };

  const openNewExpense = () => {
    setEditingExpense(null);
    setModal("expense");
  };

  const openEditExpense = (expense: Expense) => {
    setEditingExpense(expense);
    setModal("expense");
  };

  const updateReceipt = (expenseId: string, file: File) => {
    if (file.size > 2_000_000) {
      window.alert("O arquivo deve ter no máximo 2 MB para armazenamento local.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setData((current) => ({
        ...current,
        expenses: current.expenses.map((expense) =>
          expense.id === expenseId
            ? { ...expense, receiptName: file.name, receiptData: String(reader.result ?? "") }
            : expense,
        ),
      }));
    };
    reader.onerror = () => {
      console.error("Falha ao carregar o arquivo de comprovante.");
      window.alert("Não foi possível carregar o arquivo. Tente novamente.");
    };
    reader.readAsDataURL(file);
  };

  const filteredExpenses = tripExpenses.filter((expense) =>
    (!filterCategory || expense.category === filterCategory),
  );

  const changeAdminRep = (representativeId: string) => {
    setAdminRepresentativeId(representativeId);
    const firstTrip = data.trips.find((trip) => trip.representativeId === representativeId);
    if (firstTrip) setData((current) => ({ ...current, activeTripId: firstTrip.id }));
  };

  const changeRole = (nextRole: Role) => {
    setRole(nextRole);
    if (nextRole === "admin") setView("admin");
    else if (view === "admin") setView("dashboard");
  };

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">T</div>
          <div className="brand-copy"><strong>T.S.D</strong><span>Gestão de viagens</span></div>
        </div>
        <div className="nav-caption">MENU PRINCIPAL</div>
        <nav className="main-nav" aria-label="Navegação principal">
          {VIEW_ITEMS.map((item) => (
            <button
              key={item.id}
              className={`nav-item ${view === item.id ? "selected" : ""}`}
              onClick={() => { setView(item.id); setFilterCategory(""); }}
              title={item.label}
              aria-current={view === item.id ? "page" : undefined}
            >
              <span className="nav-icon" aria-hidden="true">{item.icon}</span>
              <span className="nav-label">{item.label}</span>
              {item.id === "expenses" && pendingReceipts > 0 && <span className="nav-badge">{pendingReceipts}</span>}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="demo-label"><span className="status-dot" /> Ambiente de demonstração</div>
          <div className="sidebar-profile">
            <div className="avatar">{currentRep?.initials ?? "TS"}</div>
            <div className="profile-copy"><strong>{currentRep?.name ?? "Representante"}</strong><span>Conta de demonstração</span></div>
          </div>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div className="topbar-mobile-brand"><span className="brand-mark small">T</span><strong>T.S.D</strong></div>
          <div className="trip-select-wrap">
            <span className="trip-select-label">VIAGEM ATIVA</span>
            <select
              aria-label="Selecionar viagem ativa"
              value={activeTrip?.id ?? ""}
              onChange={(event) => setData((current) => ({ ...current, activeTripId: event.target.value }))}
            >
              {data.trips.map((trip) => (
                <option key={trip.id} value={trip.id}>{trip.destination} · {data.representatives.find((rep) => rep.id === trip.representativeId)?.name}</option>
              ))}
            </select>
          </div>
          <div className="topbar-right">
            <span className="demo-pill"><span className="status-dot" /> Protótipo</span>
            <label className="role-switch">
              <span className="role-label">Visualizar como</span>
              <select aria-label="Alternar perfil de demonstração" value={role} onChange={(event) => changeRole(event.target.value as Role)}>
                <option value="representative">Representante</option>
                <option value="admin">Superior / Admin</option>
              </select>
            </label>
            <div className="avatar top-avatar">{currentRep?.initials ?? "TS"}</div>
          </div>
        </header>

        {storageError && <div className="storage-warning" role="alert">Não foi possível salvar no navegador. Verifique o espaço disponível e as permissões de armazenamento.</div>}

        <div className="page-content">
          {view === "dashboard" && activeTrip && (
            <Dashboard
              trip={activeTrip}
              repName={currentRep?.name ?? "Representante"}
              expenses={tripExpenses}
              advances={totalAdvances}
              totalExpenses={totalExpenses}
              balance={balance}
              submitted={submittedReceipts}
              pending={pendingReceipts}
              onExpenses={goToExpenses}
              onAddExpense={openNewExpense}
            />
          )}
          {view === "expenses" && (
            <ExpensesPage
              expenses={filteredExpenses}
              filterCategory={filterCategory}
              onFilterChange={setFilterCategory}
              onAdd={openNewExpense}
              onEdit={openEditExpense}
              onReceipt={updateReceipt}
            />
          )}
          {view === "advances" && (
            <AdvancesPage advances={tripAdvances} total={totalAdvances} onAdd={() => setModal("advance")} />
          )}
          {view === "itinerary" && activeTrip && <ItineraryPage trip={activeTrip} />}
          {view === "admin" && (
            <AdminPage
              data={data}
              activeTrip={activeTrip}
              representativeId={adminRepresentativeId}
              onRepresentativeChange={changeAdminRep}
              onTripChange={(tripId) => setData((current) => ({ ...current, activeTripId: tripId }))}
              onExpenses={goToExpenses}
            />
          )}
          {view === "report" && activeTrip && (
            <ReportPage
              trip={activeTrip}
              repName={currentRep?.name ?? "Representante"}
              expenses={tripExpenses}
              advances={tripAdvances}
              balance={balance}
              pending={pendingReceipts}
            />
          )}
        </div>
      </main>

      {modal === "expense" && activeTrip && (
        <ExpenseModal
          tripId={activeTrip.id}
          expense={editingExpense}
          onClose={() => { setModal(null); setEditingExpense(null); }}
          onSave={saveExpense}
        />
      )}
      {modal === "advance" && activeTrip && (
        <AdvanceModal tripId={activeTrip.id} onClose={() => setModal(null)} onSave={saveAdvance} />
      )}
    </div>
  );
}

function PageHeading({ eyebrow, title, description, action }: {
  eyebrow: string; title: string; description: string; action?: ReactNode;
}) {
  return (
    <div className="page-heading">
      <div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>
      {action && <div className="heading-action">{action}</div>}
    </div>
  );
}

function BalanceCard({ balance, label = "Saldo disponível" }: { balance: number; label?: string }) {
  const isPositive = balance >= 0;
  return (
    <div className={`balance-card ${isPositive ? "balance-positive" : "balance-negative"}`}>
      <div className="balance-top"><span>{isPositive ? "Disponível" : "A ressarcir"}</span><span className="balance-symbol">{isPositive ? "↗" : "!"}</span></div>
      <strong>{brl(Math.abs(balance))}</strong>
      <span className="balance-caption">{label}</span>
    </div>
  );
}

function Dashboard({ trip, repName, expenses, advances, totalExpenses, balance, submitted, pending, onExpenses, onAddExpense }: {
  trip: Trip; repName: string; expenses: Expense[]; advances: number; totalExpenses: number; balance: number;
  submitted: number; pending: number; onExpenses: (category?: string) => void; onAddExpense: () => void;
}) {
  const categories = CATEGORIES.map((category) => ({
    category,
    amount: expenses.filter((expense) => expense.category === category).reduce((sum, expense) => sum + expense.amount, 0),
  })).filter((item) => item.amount > 0);
  const largestCategory = Math.max(...categories.map((item) => item.amount), 1);
  const transactionCount = expenses.length;
  return (
    <>
      <PageHeading eyebrow="VISÃO GERAL" title="Painel inicial" description="Acompanhe os números e comprovantes da sua viagem." action={<button className="button button-primary" onClick={onAddExpense}><span>＋</span> Nova despesa</button>} />
      <section className="trip-banner">
        <div className="trip-banner-icon">⌖</div>
        <div className="trip-banner-info"><span>VIAGEM EM ANDAMENTO</span><h2>{trip.destination}</h2><p>{trip.company} <i>·</i> {trip.purpose}</p></div>
        <div className="trip-banner-meta"><span>REPRESENTANTE</span><strong>{repName}</strong></div>
        <div className="trip-banner-meta dates"><span>PERÍODO</span><strong>{formatDate(trip.startDate)} — {formatDate(trip.endDate)}</strong></div>
      </section>
      <section className="stats-grid">
        <button className="stat-card clickable" onClick={() => onExpenses()}>
          <div className="stat-top"><span>Total de despesas</span><span className="stat-icon coral">↘</span></div><strong>{brl(totalExpenses)}</strong><small>{transactionCount} transações registradas</small>
        </button>
        <button className="stat-card clickable" onClick={() => onExpenses()}>
          <div className="stat-top"><span>Entradas recebidas</span><span className="stat-icon mint">＋</span></div><strong>{brl(advances)}</strong><small>Adiantamentos da empresa</small>
        </button>
        <div className="stat-card balance-stat"><BalanceCard balance={balance} label="Entradas menos despesas" /></div>
        <button className="stat-card clickable" onClick={() => onExpenses()}>
          <div className="stat-top"><span>Comprovantes</span><span className="stat-icon lavender">▤</span></div>
          <strong>{submitted}<small className="stat-total"> / {submitted + pending}</small></strong>
          <small>{pending > 0 ? `${pending} pendente${pending > 1 ? "s" : ""}` : "Tudo em dia"}</small>
        </button>
      </section>
      {pending > 0 && (
        <button className="alert-banner" onClick={() => onExpenses()}>
          <span className="alert-icon">!</span><span><strong>{pending} {pending === 1 ? "comprovante pendente" : "comprovantes pendentes"}</strong><small>Adicione as notas fiscais para completar o relatório da viagem.</small></span><span className="alert-link">Ver despesas <b>→</b></span>
        </button>
      )}
      <div className="dashboard-lower">
        <section className="panel category-panel">
          <div className="panel-heading"><div><h3>Despesas por categoria</h3><p>Distribuição dos gastos desta viagem</p></div><button className="text-button" onClick={() => onExpenses()}>Ver todas <span>→</span></button></div>
          {categories.length === 0 ? <EmptyState title="Nenhuma despesa" text="As categorias serão exibidas após registrar gastos." /> : (
            <div className="category-list">
              {categories.map((item, index) => (
                <button className="category-row" key={item.category} onClick={() => onExpenses(item.category)}>
                  <span className={`category-dot category-color-${index % 5}`} />
                  <span className="category-name">{item.category}</span>
                  <span className="category-track"><i style={{ width: `${Math.max(7, item.amount / largestCategory * 100)}%` }} /></span>
                  <strong>{brl(item.amount)}</strong>
                </button>
              ))}
            </div>
          )}
        </section>
        <section className="panel recent-panel">
          <div className="panel-heading"><div><h3>Atividade recente</h3><p>Últimos lançamentos da viagem</p></div><button className="text-button" onClick={() => onExpenses()}>Ver todas <span>→</span></button></div>
          <div className="recent-list">
            {expenses.slice(0, 4).map((expense) => (
              <div className="recent-row" key={expense.id}>
                <span className={`recent-icon category-color-${CATEGORIES.indexOf(expense.category) % 5}`}>{expense.category === "Transporte" ? "↗" : expense.category === "Hospedagem" ? "⌂" : "◷"}</span>
                <span className="recent-copy"><strong>{expense.description}</strong><small>{formatDate(expense.date)} · {expense.category}</small></span>
                <strong className="recent-amount">{brl(expense.amount)}</strong>
              </div>
            ))}
            {expenses.length === 0 && <EmptyState title="Sem lançamentos" text="Adicione uma despesa para começar." />}
          </div>
        </section>
      </div>
      <p className="prototype-note"><span>i</span> Os valores são armazenados apenas neste navegador e servem para demonstração.</p>
    </>
  );
}

function EmptyState({ title, text }: { title: string; text: string }) {
  return <div className="empty-state"><span className="empty-icon">▤</span><strong>{title}</strong><p>{text}</p></div>;
}

function ExpensesPage({ expenses, filterCategory, onFilterChange, onAdd, onEdit, onReceipt }: {
  expenses: Expense[]; filterCategory: string; onFilterChange: (value: string) => void;
  onAdd: () => void; onEdit: (expense: Expense) => void; onReceipt: (id: string, file: File) => void;
}) {
  return (
    <>
      <PageHeading eyebrow="CONTROLE DA VIAGEM" title="Despesas" description="Registre os gastos e mantenha os comprovantes organizados." action={<button className="button button-primary" onClick={onAdd}>＋ Nova despesa</button>} />
      <section className="panel table-panel">
        <div className="panel-toolbar">
          <div><h3>Despesas registradas</h3><p>{expenses.length} lançamento{expenses.length === 1 ? "" : "s"}</p></div>
          <label className="filter-control"><span>Categoria</span><select value={filterCategory} onChange={(event) => onFilterChange(event.target.value)}><option value="">Todas</option>{CATEGORIES.map((category) => <option key={category}>{category}</option>)}</select></label>
        </div>
        <div className="table-scroll">
          <table>
            <thead><tr><th>DESCRIÇÃO</th><th>CATEGORIA</th><th>DATA / LOCAL</th><th>RESPONSABILIDADE</th><th>VALOR</th><th>COMPROVANTE</th><th aria-label="Ações" /></tr></thead>
            <tbody>
              {expenses.map((expense) => (
                <tr key={expense.id}>
                  <td><button className="table-primary-link" onClick={() => onEdit(expense)}>{expense.description}</button><small className="table-subtext">{expense.purpose}</small></td>
                  <td><span className="category-pill">{expense.category}</span></td>
                  <td><span>{formatDate(expense.date)}</span><small className="table-subtext">{expense.location}</small></td>
                  <td><ResponsibilityBadge expense={expense} /></td>
                  <td className="amount-cell">{brl(expense.amount)}</td>
                  <td>
                    {expense.receiptName ? <span className="receipt-ok"><span>✓</span> Enviado</span> : (
                      <label className="receipt-pending"><span>!</span> Pendente<input aria-label={`Anexar comprovante de ${expense.description}`} type="file" accept="image/*,.pdf" onChange={(event) => { const file = event.target.files?.[0]; if (file) onReceipt(expense.id, file); event.target.value = ""; }} /></label>
                    )}
                  </td>
                  <td><button className="icon-button" aria-label={`Editar ${expense.description}`} onClick={() => onEdit(expense)}>···</button></td>
                </tr>
              ))}
            </tbody>
          </table>
          {expenses.length === 0 && <EmptyState title="Nenhuma despesa encontrada" text={filterCategory ? "Tente outra categoria ou limpe o filtro." : "Adicione uma despesa para começar a acompanhar esta viagem."} />}
        </div>
      </section>
      <p className="prototype-note"><span>i</span> Os anexos ficam salvos localmente neste navegador. Evite usar documentos reais neste protótipo.</p>
    </>
  );
}

function ResponsibilityBadge({ expense }: { expense: Expense }) {
  if (expense.responsibility === "shared") return <span className="responsibility-badge shared">Compartilhada</span>;
  if (expense.responsibility === "representative") return <span className="responsibility-badge personal">Representante</span>;
  return <span className="responsibility-badge company">Empresa</span>;
}

function AdvancesPage({ advances, total, onAdd }: { advances: Advance[]; total: number; onAdd: () => void }) {
  return (
    <>
      <PageHeading eyebrow="ADIANTAMENTOS" title="Entradas" description="Registre os valores recebidos para custear a viagem." action={<button className="button button-primary" onClick={onAdd}>＋ Registrar entrada</button>} />
      <section className="advance-summary">
        <div className="advance-summary-icon">↙</div><div><span>TOTAL RECEBIDO NESTA VIAGEM</span><strong>{brl(total)}</strong><small>O saldo é atualizado automaticamente após cada lançamento.</small></div>
        <span className="transfer-tag">✓ Entradas confirmadas</span>
      </section>
      <section className="panel table-panel">
        <div className="panel-toolbar"><div><h3>Histórico de entradas</h3><p>{advances.length} lançamento{advances.length === 1 ? "" : "s"}</p></div></div>
        {advances.length ? <div className="advance-list">{advances.map((advance) => (
          <div className="advance-row" key={advance.id}><div className="advance-row-icon">＋</div><div className="advance-row-copy"><strong>{advance.description}</strong><small>{formatDate(advance.date)}</small></div><strong className="advance-amount">+ {brl(advance.amount)}</strong><span className="transfer-tag compact">Recebida</span></div>
        ))}</div> : <EmptyState title="Nenhuma entrada registrada" text="Registre o adiantamento recebido da empresa." />}
      </section>
      <p className="prototype-note"><span>i</span> As entradas são demonstrações locais e não representam transferências bancárias.</p>
    </>
  );
}

function ItineraryPage({ trip }: { trip: Trip }) {
  const forecast = [
    { category: "Hospedagem", title: "Hospedagem", note: "4 noites · estimativa regional", amount: 1480, icon: "⌂", color: "lavender" },
    { category: "Alimentação", title: "Alimentação", note: "Refeições durante a viagem", amount: 720, icon: "◷", color: "coral" },
    { category: "Transporte", title: "Locomoção", note: "Deslocamentos locais", amount: 460, icon: "↗", color: "mint" },
  ];
  const total = forecast.reduce((sum, item) => sum + item.amount, 0);
  return (
    <>
      <PageHeading eyebrow="PLANEJAMENTO" title="Itinerário e previsão" description="Uma estimativa para ajudar a planejar os custos da viagem." />
      <section className="itinerary-banner"><div className="route-visual"><span className="route-point" /><span className="route-line" /><span className="route-point destination" /></div><div className="route-copy"><span>DESTINO DA VIAGEM</span><h2>{trip.destination}</h2><p>{trip.company} · {trip.purpose}</p></div><div className="route-dates"><span>PERÍODO</span><strong>{formatDate(trip.startDate)} — {formatDate(trip.endDate)}</strong></div></section>
      <div className="forecast-intro"><div><span className="eyebrow">PREVISÃO SIMULADA</span><h2>Estimativa de gastos</h2><p>Valores ilustrativos para apoiar o planejamento da viagem.</p></div><div className="forecast-total"><span>PREVISÃO TOTAL</span><strong>{brl(total)}</strong></div></div>
      <section className="forecast-grid">{forecast.map((item) => (
        <article className="forecast-card" key={item.category}><span className={`stat-icon ${item.color}`}>{item.icon}</span><span className="forecast-category">{item.category}</span><h3>{item.title}</h3><p>{item.note}</p><strong>{brl(item.amount)}</strong><div className="forecast-bar"><i style={{ width: `${item.amount / total * 100}%` }} /></div></article>
      ))}</section>
      <div className="disclaimer"><span>i</span><p><strong>Sobre esta previsão</strong><br />As estimativas e sugestões são dados simulados para demonstração. O protótipo não consulta mapas, hotéis, restaurantes ou serviços de inteligência artificial.</p></div>
    </>
  );
}

function AdminPage({ data, activeTrip, representativeId, onRepresentativeChange, onTripChange, onExpenses }: {
  data: AppData; activeTrip: Trip; representativeId: string;
  onRepresentativeChange: (id: string) => void; onTripChange: (id: string) => void; onExpenses: () => void;
}) {
  const representativeTrips = data.trips.filter((trip) => trip.representativeId === representativeId);
  const selectedTrip = representativeTrips.find((trip) => trip.id === activeTrip.id) ?? representativeTrips[0];
  const expenses = data.expenses.filter((expense) => expense.tripId === selectedTrip?.id);
  const advances = data.advances.filter((advance) => advance.tripId === selectedTrip?.id);
  const expenseTotal = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  const advanceTotal = advances.reduce((sum, advance) => sum + advance.amount, 0);
  const balance = advanceTotal - expenseTotal;
  const rep = data.representatives.find((item) => item.id === representativeId);
  const pending = expenses.filter((expense) => !expense.receiptName).length;
  const dateTotals = useMemo(() => {
    const points = new Map<string, number>();
    expenses.forEach((expense) => points.set(expense.date, (points.get(expense.date) ?? 0) + expense.amount));
    return [...points.entries()].sort(([a], [b]) => a.localeCompare(b));
  }, [expenses]);
  const maxDaily = Math.max(...dateTotals.map(([, amount]) => amount), 1);
  return (
    <>
      <PageHeading eyebrow="VISÃO DO GESTOR" title="Administrativo" description="Acompanhe os gastos e comprovantes das viagens da equipe." />
      <section className="admin-filters panel">
        <label><span>REPRESENTANTE</span><select value={representativeId} onChange={(event) => onRepresentativeChange(event.target.value)}>{data.representatives.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
        <label><span>VIAGEM</span><select value={selectedTrip?.id ?? ""} onChange={(event) => onTripChange(event.target.value)}>{representativeTrips.map((trip) => <option key={trip.id} value={trip.id}>{trip.destination} · {formatDate(trip.startDate)}</option>)}</select></label>
        <span className="live-demo"><span className="status-dot" /> Dados locais de demonstração</span>
      </section>
      {selectedTrip ? <>
        <section className="trip-banner admin-trip-banner"><div className="trip-banner-icon">⌖</div><div className="trip-banner-info"><span>VIAGEM SELECIONADA</span><h2>{selectedTrip.destination}</h2><p>{selectedTrip.company} <i>·</i> {selectedTrip.purpose}</p></div><div className="trip-banner-meta"><span>REPRESENTANTE</span><strong>{rep?.name}</strong></div></section>
        <section className="admin-stats">
          <div className="stat-card"><div className="stat-top"><span>Total de despesas</span><span className="stat-icon coral">↘</span></div><strong>{brl(expenseTotal)}</strong><small>{expenses.length} transações</small></div>
          <div className="stat-card"><div className="stat-top"><span>Entradas recebidas</span><span className="stat-icon mint">＋</span></div><strong>{brl(advanceTotal)}</strong><small>{advances.length} lançamentos</small></div>
          <div className="stat-card"><div className="stat-top"><span>Comprovantes pendentes</span><span className="stat-icon coral">!</span></div><strong>{pending}</strong><small>de {expenses.length} despesas</small></div>
          <BalanceCard balance={balance} label="Saldo da viagem" />
        </section>
        <section className="panel timeline-panel"><div className="panel-heading"><div><h3>Ritmo de gastos</h3><p>Despesas registradas por dia</p></div><button className="text-button" onClick={onExpenses}>Ver despesas <span>→</span></button></div>
          {dateTotals.length ? <div className="timeline-chart">{dateTotals.map(([date, amount]) => <div className="timeline-column" key={date}><strong>{brl(amount)}</strong><div className="timeline-track"><i style={{ height: `${Math.max(8, amount / maxDaily * 100)}%` }} /></div><span>{new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "short" }).format(new Date(`${date}T12:00:00`))}</span></div>)}</div> : <EmptyState title="Sem dados de gastos" text="As despesas da viagem aparecerão aqui." />}
        </section>
        <section className="panel table-panel admin-expenses"><div className="panel-toolbar"><div><h3>Despesas da viagem</h3><p>Visão geral dos lançamentos</p></div><button className="button button-secondary" onClick={onExpenses}>Abrir despesas</button></div>
          <div className="admin-expense-list">{expenses.slice(0, 5).map((expense) => <div className="admin-expense-row" key={expense.id}><span className="category-dot category-color-1" /><strong>{expense.description}</strong><span>{expense.category}</span><span>{expense.receiptName ? <span className="receipt-ok">✓ Enviado</span> : <span className="receipt-pending static">! Pendente</span>}</span><b>{brl(expense.amount)}</b></div>)}</div>
        </section>
      </> : <EmptyState title="Nenhuma viagem encontrada" text="Selecione outro representante." />}
      <p className="prototype-note"><span>i</span> O painel administrativo usa dados locais. O protótipo não sincroniza alterações em tempo real entre usuários.</p>
    </>
  );
}

function ReportPage({ trip, repName, expenses, advances, balance, pending }: {
  trip: Trip; repName: string; expenses: Expense[]; advances: Advance[]; balance: number; pending: number;
}) {
  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  const totalAdvances = advances.reduce((sum, advance) => sum + advance.amount, 0);
  const exportCsv = () => {
    const rows: (string | number)[][] = [
      ["Tipo", "Data", "Descrição", "Categoria", "Local", "Justificativa", "Responsabilidade", "Parcela empresa (R$)", "Parcela representante (R$)", "Valor (R$)", "Comprovante"],
      ...expenses.map((expense) => [
        "Despesa", expense.date, expense.description, expense.category, expense.location, expense.purpose,
        responsibilityText(expense.responsibility), expense.companyShare.toFixed(2), expense.representativeShare.toFixed(2),
        expense.amount.toFixed(2), expense.receiptName ? `Enviado: ${expense.receiptName}` : "Pendente",
      ]),
      ...advances.map((advance) => ["Entrada", advance.date, advance.description, "", "", "", "Empresa", advance.amount.toFixed(2), "0.00", advance.amount.toFixed(2), "N/A"]),
      [],
      ["Resumo", "Empresa", trip.company],
      ["Resumo", "Representante", repName],
      ["Resumo", "Destino", trip.destination],
      ["Resumo", "Total de entradas (R$)", totalAdvances.toFixed(2)],
      ["Resumo", "Total de despesas (R$)", totalExpenses.toFixed(2)],
      ["Resumo", balance >= 0 ? "Saldo disponível (R$)" : "A ressarcir (R$)", Math.abs(balance).toFixed(2)],
      ["Resumo", "Comprovantes pendentes", pending],
    ];
    const escape = (cell: string | number) => `"${String(cell).replace(/"/g, '""')}"`;
    const csv = "\uFEFF" + rows.map((row) => row.map(escape).join(";")).join("\r\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8;" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = `tsd-relatorio-${trip.destination.toLowerCase().replace(/[^a-z0-9]+/g, "-")}.csv`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  };
  return (
    <>
      <PageHeading eyebrow="PRESTAÇÃO DE CONTAS" title="Relatório" description="Revise os valores da viagem e exporte os lançamentos." action={<button className="button button-primary" onClick={exportCsv}><span>↓</span> Exportar CSV</button>} />
      <section className="report-trip panel"><div className="report-trip-icon">▤</div><div><span>RELATÓRIO DA VIAGEM</span><h2>{trip.destination}</h2><p>{trip.company} · {repName} · {formatDate(trip.startDate)} a {formatDate(trip.endDate)}</p></div><span className="report-demo-tag">Prévia local</span></section>
      <section className="report-totals">
        <div className="report-total-card"><span>ENTRADAS</span><strong>{brl(totalAdvances)}</strong><small>{advances.length} adiantamento{advances.length === 1 ? "" : "s"}</small></div>
        <div className="report-total-card"><span>DESPESAS</span><strong>{brl(totalExpenses)}</strong><small>{expenses.length} lançamento{expenses.length === 1 ? "" : "s"}</small></div>
        <BalanceCard balance={balance} label="Resultado da viagem" />
      </section>
      <section className="panel table-panel report-check"><div className="panel-heading"><div><h3>Conferência de comprovantes</h3><p>Verifique os documentos antes de exportar</p></div><span className={pending ? "pending-count" : "all-clear"}>{pending ? `${pending} pendente${pending > 1 ? "s" : ""}` : "✓ Tudo em dia"}</span></div>
        {expenses.length ? <div className="report-receipts">{expenses.map((expense) => <div className="report-receipt-row" key={expense.id}><span className={expense.receiptName ? "receipt-check done" : "receipt-check"}>{expense.receiptName ? "✓" : "!"}</span><span><strong>{expense.description}</strong><small>{formatDate(expense.date)} · {brl(expense.amount)}</small></span><span className={expense.receiptName ? "receipt-ok" : "receipt-pending static"}>{expense.receiptName ? "Enviado" : "Pendente"}</span></div>)}</div> : <EmptyState title="Sem despesas" text="Não há itens para conferir nesta viagem." />}
      </section>
      <p className="prototype-note"><span>i</span> O arquivo CSV é gerado no navegador. Nenhuma informação é enviada a um servidor.</p>
    </>
  );
}

function responsibilityText(responsibility: Responsibility) {
  if (responsibility === "shared") return "Compartilhada";
  return responsibility === "company" ? "Empresa" : "Representante";
}

function ExpenseModal({ tripId, expense, onClose, onSave }: {
  tripId: string; expense: Expense | null; onClose: () => void; onSave: (expense: Expense) => void;
}) {
  const [description, setDescription] = useState(expense?.description ?? "");
  const [category, setCategory] = useState(expense?.category ?? CATEGORIES[0]);
  const [amount, setAmount] = useState(expense ? String(expense.amount) : "");
  const [date, setDate] = useState(expense?.date ?? localDateValue());
  const [location, setLocation] = useState(expense?.location ?? "");
  const [purpose, setPurpose] = useState(expense?.purpose ?? "");
  const [responsibility, setResponsibility] = useState<Responsibility>(expense?.responsibility ?? "company");
  const [companyShare, setCompanyShare] = useState(expense ? String(expense.companyShare) : "");
  const [representativeShare, setRepresentativeShare] = useState(expense ? String(expense.representativeShare) : "");
  const [receiptName, setReceiptName] = useState(expense?.receiptName ?? "");
  const [receiptData, setReceiptData] = useState(expense?.receiptData ?? "");
  const [error, setError] = useState("");
  const totalAmount = Number(amount) || 0;

  useEffect(() => {
    if (responsibility === "company") { setCompanyShare(amount); setRepresentativeShare("0"); }
    if (responsibility === "representative") { setCompanyShare("0"); setRepresentativeShare(amount); }
    if (responsibility === "shared" && !expense) { setCompanyShare(""); setRepresentativeShare(""); }
  }, [responsibility, amount, expense]);

  const handleFile = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (file.size > 2_000_000) {
      setError("O arquivo deve ter no máximo 2 MB para armazenamento local.");
      event.target.value = "";
      return;
    }
    const reader = new FileReader();
    reader.onload = () => { setReceiptName(file.name); setReceiptData(String(reader.result ?? "")); setError(""); };
    reader.onerror = () => setError("Não foi possível ler o arquivo selecionado.");
    reader.readAsDataURL(file);
  };

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const numericAmount = Number(amount);
    const company = Number(companyShare) || 0;
    const representative = Number(representativeShare) || 0;
    if (!Number.isFinite(numericAmount) || numericAmount <= 0) { setError("Informe um valor maior que zero."); return; }
    if (responsibility === "shared" && Math.round((company + representative) * 100) !== Math.round(numericAmount * 100)) {
      setError("A soma das parcelas da empresa e do representante deve ser igual ao valor total.");
      return;
    }
    onSave({
      id: expense?.id ?? `exp-${Date.now()}`, tripId, description: description.trim(), category, amount: numericAmount,
      date, location: location.trim(), purpose: purpose.trim(), responsibility,
      companyShare: responsibility === "company" ? numericAmount : responsibility === "representative" ? 0 : company,
      representativeShare: responsibility === "representative" ? numericAmount : responsibility === "company" ? 0 : representative,
      receiptName, receiptData,
    });
  };

  return (
    <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="expense-modal-title">
        <div className="modal-heading"><div><span className="eyebrow">{expense ? "ATUALIZAÇÃO" : "NOVO LANÇAMENTO"}</span><h2 id="expense-modal-title">{expense ? "Editar despesa" : "Adicionar despesa"}</h2></div><button className="modal-close" onClick={onClose} aria-label="Fechar">×</button></div>
        <form onSubmit={submit}>
          <div className="form-grid">
            <label className="form-field full"><span>Descrição</span><input required maxLength={100} value={description} onChange={(event) => setDescription(event.target.value)} placeholder="Ex.: Almoço com cliente" /></label>
            <label className="form-field"><span>Categoria</span><select value={category} onChange={(event) => setCategory(event.target.value)}>{CATEGORIES.map((item) => <option key={item}>{item}</option>)}</select></label>
            <label className="form-field"><span>Valor total (R$)</span><input required type="number" min="0.01" step="0.01" value={amount} onChange={(event) => setAmount(event.target.value)} placeholder="0,00" /></label>
            <label className="form-field"><span>Data</span><input required type="date" value={date} onChange={(event) => setDate(event.target.value)} /></label>
            <label className="form-field"><span>Local</span><input value={location} onChange={(event) => setLocation(event.target.value)} placeholder="Cidade ou estabelecimento" /></label>
            <label className="form-field full"><span>Finalidade / justificativa</span><input required value={purpose} onChange={(event) => setPurpose(event.target.value)} placeholder="Por que este gasto foi necessário?" /></label>
            <label className="form-field full"><span>Responsabilidade pelo pagamento</span><select value={responsibility} onChange={(event) => setResponsibility(event.target.value as Responsibility)}><option value="company">Empresa</option><option value="representative">Representante</option><option value="shared">Compartilhada</option></select></label>
            {responsibility === "shared" && <>
              <label className="form-field"><span>Parcela da empresa (R$)</span><input required type="number" min="0" step="0.01" value={companyShare} onChange={(event) => setCompanyShare(event.target.value)} /></label>
              <label className="form-field"><span>Parcela do representante (R$)</span><input required type="number" min="0" step="0.01" value={representativeShare} onChange={(event) => setRepresentativeShare(event.target.value)} /></label>
              <div className={`share-hint full ${Math.round((Number(companyShare) + Number(representativeShare)) * 100) === Math.round(totalAmount * 100) ? "valid" : ""}`}>Soma das parcelas: {brl((Number(companyShare) || 0) + (Number(representativeShare) || 0))} <span>· Total: {brl(totalAmount)}</span></div>
            </>}
            <div className="form-field full"><span>Comprovante</span><label className="file-drop"><span className="file-icon">↑</span><span>{receiptName ? <><strong>{receiptName}</strong><small>Selecionar outro arquivo</small></> : <><strong>Adicionar foto ou arquivo</strong><small>Imagem ou PDF · até 2 MB</small></>}</span><input type="file" accept="image/*,.pdf" onChange={handleFile} /></label></div>
          </div>
          {error && <div className="form-error" role="alert">{error}</div>}
          <div className="modal-actions"><button type="button" className="button button-secondary" onClick={onClose}>Cancelar</button><button type="submit" className="button button-primary">{expense ? "Salvar alterações" : "Adicionar despesa"}</button></div>
        </form>
      </section>
    </div>
  );
}

function AdvanceModal({ tripId, onClose, onSave }: { tripId: string; onClose: () => void; onSave: (advance: Advance) => void }) {
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(localDateValue());
  const [description, setDescription] = useState("");
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const value = Number(amount);
    if (!Number.isFinite(value) || value <= 0) return;
    onSave({ id: `adv-${Date.now()}`, tripId, amount: value, date, description: description.trim() || "Adiantamento da empresa" });
  };
  return (
    <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section className="modal-card compact-modal" role="dialog" aria-modal="true" aria-labelledby="advance-modal-title">
        <div className="modal-heading"><div><span className="eyebrow">NOVO LANÇAMENTO</span><h2 id="advance-modal-title">Registrar entrada</h2></div><button className="modal-close" onClick={onClose} aria-label="Fechar">×</button></div>
        <form onSubmit={submit}><div className="form-grid">
          <label className="form-field full"><span>Valor recebido (R$)</span><input required autoFocus type="number" min="0.01" step="0.01" value={amount} onChange={(event) => setAmount(event.target.value)} placeholder="0,00" /></label>
          <label className="form-field full"><span>Data de recebimento</span><input required type="date" value={date} onChange={(event) => setDate(event.target.value)} /></label>
          <label className="form-field full"><span>Descrição</span><input value={description} onChange={(event) => setDescription(event.target.value)} placeholder="Ex.: Adiantamento complementar" /></label>
        </div><div className="modal-actions"><button type="button" className="button button-secondary" onClick={onClose}>Cancelar</button><button type="submit" className="button button-primary">＋ Registrar entrada</button></div></form>
      </section>
    </div>
  );
}

export default App;
