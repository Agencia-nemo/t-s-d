# T.S.D — protótipo de gestão de viagens

Protótipo client-side para registrar despesas e entradas de viagens comerciais, acompanhar comprovantes e exportar um relatório CSV.

## Executar localmente

Requisitos: Node.js 20.19+ ou 22.12+ e npm. O `index.html` não deve ser aberto diretamente: como o app usa React e TypeScript, ele precisa ser servido pelo Vite.

No Windows, instale o Node.js LTS se necessário e execute `Iniciar-Prototipo.bat` na pasta do projeto. O script instala as dependências na primeira execução, inicia o servidor e abre o protótipo no navegador padrão. Para usar o Google Chrome, acesse `http://localhost:5173`. Mantenha a janela do terminal aberta enquanto usa o protótipo.

Ou execute manualmente:

```bash
npm install
npm run dev
```

Abra o endereço local exibido pelo Vite. Para validar a compilação de produção:

```bash
npm run build
npm run preview
```

## Configuração do Supabase

O cliente oficial do Supabase está instalado e configurado em `src/lib/supabase.ts`. As credenciais locais ficam em `.env.local`, que não deve ser compartilhado nem enviado ao Git. Para configurar outro ambiente, copie `.env.example` para `.env.local` e preencha a URL do projeto e a chave pública (`publishable`).

Use somente a chave pública no frontend. Nunca inclua a chave `service_role` no código do navegador. A conexão do cliente está preparada, mas login e armazenamento remoto ainda dependem da criação das tabelas, das políticas de segurança (RLS) e da integração dos fluxos do app.

## Executar em container

Requisitos: Docker Engine em execução.

Para criar uma imagem de produção a partir da raiz do projeto:

```bash
docker build -t tsd-expense-prototype:local .
```

A imagem serve os arquivos estáticos na porta `8080`, usa `/healthz` como endpoint de saúde e inclui fallback de navegação para as rotas do frontend.

## Demonstração

- Use o seletor superior para alternar entre viagens.
- Use “Visualizar como” para alternar entre representante e superior/admin.
- Adicione despesas e entradas; os dados são persistidos no `localStorage` deste navegador.
- Despesas compartilhadas exigem que as parcelas da empresa e do representante correspondam ao valor total.
- Anexe comprovantes de até 2 MB por arquivo.
- Exporte o resumo da viagem em CSV pela página Relatório.

Todos os dados são exemplos locais. Não use informações financeiras ou comprovantes reais. O protótipo não tem backend, autenticação, integração bancária, mapas, IA ou sincronização entre usuários.
