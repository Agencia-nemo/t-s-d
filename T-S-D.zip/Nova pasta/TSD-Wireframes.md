# T.S.D — Wireframes de baixa fidelidade

Diagramas textuais para orientar a estrutura e a navegação do protótipo. Eles representam hierarquia e conteúdo, não cores, dimensões finais ou comportamento visual detalhado.

## 1. Estrutura geral — navegação expandida

Em telas desktop, a navegação lateral fica visível ao lado da área principal.

```text
┌──────────────────────┬─────────────────────────────────────────────────────────────┐
│ [T] T.S.D            │ VIAGEM ATIVA                       Protótipo  Visualizar como│
│     Gestão de viagens│ [São Paulo, SP · Mariana Costa ▾]           [Representante ▾]│
├──────────────────────┼─────────────────────────────────────────────────────────────┤
│ MENU PRINCIPAL       │                                                             │
│                      │                 CONTEÚDO DA PÁGINA                          │
│ [⌂] Painel inicial   │                                                             │
│ [↗] Despesas       2 │                                                             │
│ [+] Entradas         │                                                             │
│ [⌖] Itinerário e     │                                                             │
│     previsão         │                                                             │
│ [▣] Administrativo   │                                                             │
│ [▤] Relatório        │                                                             │
│                      │                                                             │
│                      │                                                             │
│                      │                                                             │
│ ● Ambiente demo      │                                                             │
│ [MC] Mariana Costa   │                                                             │
│      Conta demo      │                                                             │
└──────────────────────┴─────────────────────────────────────────────────────────────┘
```

**Comportamento:** o item selecionado recebe destaque; o contador de comprovantes pendentes pode aparecer junto a Despesas. O seletor de viagem atualiza os dados da tela. A troca para “Superior / Admin” abre a tela Administrativa.

## 2. Navegação lateral — recolhida

Em larguras menores, a barra se reduz a ícones. Cada botão deve continuar acessível por teclado e identificável por tooltip ou rótulo acessível.

```text
┌──────┬─────────────────────────────────────────────────────────────────────────────┐
│ [T]  │ [T.S.D]       Viagem ativa: São Paulo, SP ▾      [Protótipo] [Perfil ▾] [MC]│
├──────┼─────────────────────────────────────────────────────────────────────────────┤
│ [⌂]  │                                                                             │
│ [↗]² │                         CONTEÚDO DA PÁGINA                                  │
│ [+]  │                                                                             │
│ [⌖]  │                                                                             │
│ [▣]  │                                                                             │
│ [▤]  │                                                                             │
│      │                                                                             │
│ [MC] │                                                                             │
└──────┴─────────────────────────────────────────────────────────────────────────────┘
```

Em dispositivos móveis, manter a navegação recolhida e preservar os rótulos da página, o seletor de perfil e os controles principais. Adaptar cartões e formulários para uma coluna quando necessário.

## 3. Painel inicial (Dashboard)

```text
┌───────────────────────────────────────────────────────────────────────────────────┐
│ VISÃO GERAL                                                                         │
│ Painel inicial                                      [+ Nova despesa]              │
│ Acompanhe os números e comprovantes da sua viagem.                                  │
├───────────────────────────────────────────────────────────────────────────────────┤
│ [⌖] VIAGEM EM ANDAMENTO                      REPRESENTANTE        PERÍODO            │
│     São Paulo, SP                            Mariana Costa        20–24 out.         │
│     NorteSul Equipamentos · Visita a clientes e apresentação de catálogo            │
├──────────────────┬──────────────────┬──────────────────┬──────────────────────────┤
│ TOTAL DESPESAS   │ ENTRADAS         │ SALDO            │ COMPROVANTES             │
│ R$ 1.791,40      │ R$ 3.300,00      │ Disponível       │ 3 / 5                    │
│ 5 transações     │ Adiantamentos    │ R$ 1.508,60      │ 2 pendentes              │
├───────────────────────────────────────────────────────────────────────────────────┤
│ [!] 2 comprovantes pendentes                    [Ver despesas →]                   │
├─────────────────────────────────────┬─────────────────────────────────────────────┤
│ DESPESAS POR CATEGORIA               │ ATIVIDADE RECENTE                           │
│ Alimentação  ━━━━━━━ R$ 434,50       │ Almoço com cliente       20 out. R$ 186,50   │
│ Hospedagem   ━━━━━━━━━ R$ 1.240,00   │ Aplicativo transporte    20 out. R$ 74,90    │
│ Transporte   ━━━      R$ 116,90      │ Hotel Central            20 out. R$ 1.240,00 │
│                         [Ver todas →]│                               [Ver todas →]│
└─────────────────────────────────────┴─────────────────────────────────────────────┘
│ i Valores de demonstração salvos apenas neste navegador.                            │
└───────────────────────────────────────────────────────────────────────────────────┘
```

Indicadores e categorias de despesa devem abrir Despesas; categorias devem aplicar seu filtro. O saldo disponível aparece em azul. Quando negativo, mostrar “A ressarcir” e o valor absoluto em vermelho.

## 4. Despesas (Expenses)

```text
┌───────────────────────────────────────────────────────────────────────────────────┐
│ CONTROLE DA VIAGEM                                                                  │
│ Despesas                                             [+ Nova despesa]               │
│ Registre os gastos e mantenha os comprovantes organizados.                         │
├───────────────────────────────────────────────────────────────────────────────────┤
│ DESPESAS REGISTRADAS · 5 lançamentos                  Categoria [Todas ▾]           │
├────────────────┬─────────────┬─────────────┬────────────────┬───────────┬──────────┤
│ DESCRIÇÃO      │ CATEGORIA   │ DATA / LOCAL│ RESPONSABILIDADE│ VALOR     │ COMPROV. │
├────────────────┼─────────────┼─────────────┼────────────────┼───────────┼──────────┤
│ Almoço cliente │ Alimentação │ 20 out.      │ Empresa        │ R$ 186,50 │ ✓ Enviado│
│ Justificativa… │             │ Vila Olímpia │                │           │          │
├────────────────┼─────────────┼─────────────┼────────────────┼───────────┼──────────┤
│ Hotel Central  │ Hospedagem  │ 20 out.      │ Empresa        │ R$ 1.240  │ ✓ Enviado│
│ Justificativa… │             │ Pinheiros    │                │           │          │
├────────────────┼─────────────┼─────────────┼────────────────┼───────────┼──────────┤
│ Jantar reunião │ Alimentação │ 21 out.      │ Compartilhada  │ R$ 248,00 │ ! Pendente│
│ Justificativa… │             │ Itaim Bibi   │                │           │          │
├────────────────┴─────────────┴─────────────┴────────────────┴───────────┴──────────┤
│ i Anexos demonstrativos são locais. Não use comprovantes reais.                     │
└───────────────────────────────────────────────────────────────────────────────────┘
```

“Nova despesa” abre o formulário de cadastro. Selecionar uma despesa abre o formulário para edição. O controle de comprovante permite anexar arquivo local. No celular, reorganizar cada linha como cartão ou permitir rolagem horizontal claramente indicada.

### Formulário de despesa (modal)

```text
┌──────────────────────────── ADICIONAR DESPESA ──────────────────────────── [×] ┐
│ Descrição [______________________________________________________________]       │
│ Categoria [Alimentação ▾]                 Valor total (R$) [____________]       │
│ Data      [______________]                 Local            [____________]       │
│ Finalidade / justificativa [____________________________________________]       │
│ Responsabilidade [Empresa ▾]                                                 │
│ Se Compartilhada: Parcela empresa [____]   Parcela representante [____]     │
│ Soma das parcelas: R$ 0,00 · Total: R$ 0,00                                  │
│ Comprovante [↑ Adicionar foto ou arquivo · Imagem/PDF · até 2 MB]           │
│                                                           [Cancelar] [Salvar]│
└─────────────────────────────────────────────────────────────────────────────┘
```

Se as parcelas compartilhadas não somarem exatamente o total, mostrar erro e impedir o salvamento.

## 5. Entradas (Advances)

```text
┌───────────────────────────────────────────────────────────────────────────────────┐
│ ADIANTAMENTOS                                                                       │
│ Entradas                                            [+ Registrar entrada]          │
│ Registre os valores recebidos para custear a viagem.                                │
├───────────────────────────────────────────────────────────────────────────────────┤
│ TOTAL RECEBIDO NESTA VIAGEM                                                         │
│ R$ 3.300,00                                        ✓ Entradas demonstrativas       │
│ O saldo é atualizado após cada lançamento.                                         │
├───────────────────────────────────────────────────────────────────────────────────┤
│ HISTÓRICO DE ENTRADAS                                                               │
│ [+] Adiantamento inicial                       19 out.              + R$ 2.500,00   │
│ [+] Complemento para hospedagem                21 out.              + R$   800,00   │
└───────────────────────────────────────────────────────────────────────────────────┘
```

### Formulário de entrada (modal)

```text
┌────────────────────── REGISTRAR ENTRADA ──────────────────────── [×] ┐
│ Valor recebido (R$) [___________________________________________]     │
│ Data de recebimento [___________________________________________]     │
│ Descrição           [___________________________________________]     │
│                                             [Cancelar] [Registrar]   │
└──────────────────────────────────────────────────────────────────────┘
```

## 6. Itinerário e previsão (Itinerary & Forecast)

```text
┌───────────────────────────────────────────────────────────────────────────────────┐
│ PLANEJAMENTO                                                                        │
│ Itinerário e previsão                                                               │
│ Uma estimativa para ajudar a planejar os custos da viagem.                          │
├───────────────────────────────────────────────────────────────────────────────────┤
│ ● - - - - - - - - - - - - - - - - - - - - ●   DESTINO DA VIAGEM                    │
│                                                 São Paulo, SP                       │
│                                                 NorteSul Equipamentos · Visitas     │
│                                                 PERÍODO 20–24 out.                  │
├───────────────────────────────────────────────────────────────────────────────────┤
│ PREVISÃO SIMULADA                                      PREVISÃO TOTAL               │
│ Estimativa de gastos                                    R$ 2.660,00                 │
│                                                                                     │
│ ┌────────────────────┐ ┌────────────────────┐ ┌────────────────────┐             │
│ │ HOSPEDAGEM         │ │ ALIMENTAÇÃO        │ │ LOCOMOÇÃO          │             │
│ │ 4 noites           │ │ Refeições           │ │ Deslocamentos      │             │
│ │ R$ 1.480,00        │ │ R$ 720,00           │ │ R$ 460,00          │             │
│ │ ━━━━━━━━━━━━━      │ │ ━━━━━━━            │ │ ━━━━━              │             │
│ └────────────────────┘ └────────────────────┘ └────────────────────┘             │
├───────────────────────────────────────────────────────────────────────────────────┤
│ i Sobre esta previsão: estimativas e recomendações são dados simulados.             │
│   Nenhuma consulta real a mapas, hotéis, restaurantes ou serviços de IA.             │
└───────────────────────────────────────────────────────────────────────────────────┘
```

## 7. Administrativo (Admin)

```text
┌───────────────────────────────────────────────────────────────────────────────────┐
│ VISÃO DO GESTOR                                                                     │
│ Administrativo                                                                      │
│ Acompanhe os gastos e comprovantes das viagens da equipe.                           │
├───────────────────────────────────────────────────────────────────────────────────┤
│ REPRESENTANTE [Mariana Costa ▾]   VIAGEM [São Paulo · 20 out. ▾]                    │
│ ● Dados locais de demonstração                                                      │
├───────────────────────────────────────────────────────────────────────────────────┤
│ [⌖] VIAGEM SELECIONADA                         REPRESENTANTE                         │
│     São Paulo, SP                              Mariana Costa                         │
│     NorteSul Equipamentos · Visitas a clientes                                     │
├──────────────────┬─────────────────┬───────────────────┬─────────────────────────┤
│ DESPESAS         │ ENTRADAS        │ COMPROV. PENDENTES│ SALDO                   │
│ R$ 1.791,40      │ R$ 3.300,00     │ 2 de 5            │ Disponível R$ 1.508,60  │
├───────────────────────────────────────────────────────────────────────────────────┤
│ RITMO DE GASTOS                                            [Ver despesas →]         │
│ R$ 1.500 ┤ █                                                                    │
│ R$   500 ┤ █          █                                                         │
│          └────────────────────────────────────────────────────────────────       │
│            20 out.     21 out.     22 out.                                        │
├───────────────────────────────────────────────────────────────────────────────────┤
│ DESPESAS DA VIAGEM                                             [Abrir despesas]    │
│ ● Almoço com cliente    Alimentação     ✓ Enviado            R$ 186,50              │
│ ● Hotel Central         Hospedagem      ✓ Enviado          R$ 1.240,00              │
│ ● Jantar após reunião   Alimentação     ! Pendente           R$ 248,00              │
└───────────────────────────────────────────────────────────────────────────────────┘
```

Os seletores permitem mudar representante e viagem. A tela mostra dados de demonstração locais e não deve sugerir sincronização ou atividade de outros usuários em tempo real.

## 8. Relatório (Report)

```text
┌───────────────────────────────────────────────────────────────────────────────────┐
│ PRESTAÇÃO DE CONTAS                                       [↓ Exportar CSV]         │
│ Relatório                                                                           │
│ Revise os valores da viagem e exporte os lançamentos.                               │
├───────────────────────────────────────────────────────────────────────────────────┤
│ [▤] RELATÓRIO DA VIAGEM                                Prévia local                 │
│     São Paulo, SP · NorteSul Equipamentos · Mariana Costa · 20–24 out.              │
├──────────────────────┬──────────────────────┬────────────────────────────────────┤
│ ENTRADAS             │ DESPESAS             │ RESULTADO DA VIAGEM                 │
│ R$ 3.300,00          │ R$ 1.791,40          │ Disponível R$ 1.508,60              │
│ 2 adiantamentos      │ 5 lançamentos       │                                    │
├───────────────────────────────────────────────────────────────────────────────────┤
│ CONFERÊNCIA DE COMPROVANTES                               2 pendentes              │
│ ✓ Almoço com cliente             20 out. · R$ 186,50                 Enviado       │
│ ✓ Hotel Central                  20 out. · R$ 1.240,00                Enviado       │
│ ! Jantar após reunião            21 out. · R$ 248,00                  Pendente      │
│ ! Estacionamento                 22 out. · R$ 42,00                   Pendente      │
└───────────────────────────────────────────────────────────────────────────────────┘
```

O CSV é criado e baixado no navegador. Nenhuma informação é enviada a um servidor.

## 9. Fluxo de navegação

```text
                         ┌─────────────────────┐
                         │   Painel inicial    │
                         └──────────┬──────────┘
                                    │
           ┌────────────────────────┼────────────────────────┐
           ▼                        ▼                        ▼
   ┌──────────────┐        ┌────────────────┐       ┌────────────────────┐
   │  Despesas    │        │   Entradas     │       │ Itinerário e       │
   │  + comprov.  │        │  + adiantam.   │       │ previsão           │
   └──────┬───────┘        └───────┬────────┘       └────────────────────┘
          │                        │
          └─────────────┬──────────┘
                        ▼
                 ┌──────────────┐
                 │  Relatório   │ ─── Exportar CSV
                 └──────────────┘

   Perfil Superior/Admin ──► Administrativo ──► selecionar representante/viagem
```

## 10. Notas de leitura

- Os valores nos diagramas são exemplos ilustrativos; os dados definitivos vêm do conjunto de demonstração carregado pela aplicação.
- Os nomes entre colchetes representam campos, botões ou seletores.
- `✓ Enviado` e `! Pendente` devem sempre incluir texto, não apenas cor ou ícone.
- Em mobile, manter a hierarquia de conteúdo, permitir leitura e interação sem depender de hover e reduzir grades de várias colunas para cartões empilhados.
- Os wireframes refletem um protótipo local: não representam login, upload remoto, integrações externas ou colaboração em tempo real.
